<?php
//Heading
$_['heading_title'] = 'Rakuten Connector - Cartão de Crédito';

//Text
$_['text_rakuten_cartao'] = '<img src="view/image/payment/rakuten.png" style="width: 117px" />';
