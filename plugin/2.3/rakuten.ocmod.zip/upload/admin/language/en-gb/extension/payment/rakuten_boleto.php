<?php
//Heading
$_['heading_title'] = 'Rakuten Connector - Boleto';

//Text
$_['text_rakuten_boleto'] = '<img src="view/image/payment/rakuten.png" style="width: 117px" />';
