<?php
//Text
$_['text_boleto']    = 'Rakuten Boleto';
$_['text_cartao']    = 'Rakuten Cartão de Crédito';

$_['rakuten_success'] = '<p>O <strong>Pedido %s</strong> foi recebido e o status do pedido é %s. <br>Você pode visualizar o histórico de pedidos acessando a página <a href="%s">minha conta</a>.</p>';
$_['rakuten_failure'] = '<p>O pedido %s ficou com o status %s, favor ligar para sua operadora e verificar o problema</p>';

$_['rakuten_title_success'] = 'Seu pedido foi realizado';
$_['rakuten_title_failure'] = 'Infelizmente seu pedido foi cancelado';